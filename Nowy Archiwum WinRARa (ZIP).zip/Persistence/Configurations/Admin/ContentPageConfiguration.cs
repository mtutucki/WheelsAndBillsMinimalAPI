﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using WheelsAndBillsAPI.Domain.Entities.Admin;

namespace Infrastructure.Persistence.Configurations.Admin
{
    public class ContentPageConfiguration : IEntityTypeConfiguration<ContentPage>
    {
        public void Configure(EntityTypeBuilder<ContentPage> builder)
        {
            builder.HasKey(p => p.Id);

            builder.Property(p => p.Slug)
                .IsRequired()
                .HasMaxLength(100);

            builder.HasIndex(p => p.Slug)
                .IsUnique();
        }
    }

}
