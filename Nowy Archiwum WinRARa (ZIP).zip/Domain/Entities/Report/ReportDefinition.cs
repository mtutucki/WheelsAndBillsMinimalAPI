﻿namespace WheelsAndBillsAPI.Domain.Entities.Report
{
    public class ReportDefinition
    {
        public Guid Id { get; set; }
        public string Code { get; set; } = null!;
    }
}
