﻿namespace WheelsAndBillsAPI.Domain.Entities.Vehicles
{
    public class VehicleStatus
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }

}
