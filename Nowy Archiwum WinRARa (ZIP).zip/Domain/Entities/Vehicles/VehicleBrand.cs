﻿namespace WheelsAndBillsAPI.Domain.Entities.Vehicles
{
    public class VehicleBrand
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
