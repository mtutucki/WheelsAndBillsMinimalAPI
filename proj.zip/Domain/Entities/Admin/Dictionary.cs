﻿namespace WheelsAndBillsAPI.Domain.Entities.Admin
{
    public class Dictionary
    {
        public Guid Id { get; set; }
        public string Code { get; set; } = null!;
    }

}
