﻿namespace WheelsAndBillsAPI.Domain.Entities.Vehicles
{
    public class VehicleType
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }
}


