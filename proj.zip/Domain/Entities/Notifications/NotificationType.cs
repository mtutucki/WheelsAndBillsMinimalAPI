﻿namespace WheelsAndBillsAPI.Domain.Entities.Notification
{
    public class NotificationType
    {
        public Guid Id { get; set; }
        public string Code { get; set; } = null!;
    }
}
