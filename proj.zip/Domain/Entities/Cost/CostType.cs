﻿namespace WheelsAndBillsAPI.Domain.Entities.Cost
{
    public class CostType
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }

}
