﻿namespace WheelsAndBillsAPI.Endpoints.Admin.DTO
{
    public record CreatePageDTO(string Title, string Slug);
}
